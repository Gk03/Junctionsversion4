Rails.application.routes.draw do
  root 'home#index'
  
  get 'signup', to: 'users#new', as: 'signup'
  post 'signup', to: 'users#create', as: 'signup_post'

  get 'login', to: 'session#new', as: 'login'
  post 'login', to: 'session#create', as: 'login_post'
  get 'logout', to: 'session#destroy', as: 'logout'
  
  get 'listings', to: 'listings#list', as: 'listings'
  get 'listing', to: 'listings#new', as: 'listing'
  post 'listing', to: 'listings#create', as: 'listing_post'

  get 'departments', to: 'listings#departments', as: 'get_departments'

  get 'home', to: 'home#index', as: 'home'
end
