class ApplicationController < ActionController::Base
    include SessionHelper
end
