class UsersController < ApplicationController
  include StoresHelper
  def new
    @errors = nil
  end

  def create
    name = params[:name]
    email = params[:email]
    password = params[:password]
    store = params[:store]
    
    user = User.new
    user.name = name
    user.email = email
    user.password = password
    user.store_id = store

    if user.valid?
      user.active = true
      user.save
      session[:user_id] = user.id
      redirect_to root_url, notice: "Logged in!"
    else
      @errors = user.errors.full_messages
      render "new"
    end
  end

  def update
  end
end
