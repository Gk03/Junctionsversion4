class ListingsController < ApplicationController
  include StoresHelper

  def new
  end

  def create
    store = params[:store]
    department = params[:department]
    start = params[:start]
    endTime = params[:end]
    
    if store != nil && department != nil && start != nil && endTime != nil
      shift = Shift.new
      shift.store_id = store
      shift.department_id = department
      shift.start = start
      shift.end = endTime
      shift.active = true
      shift.save

      redirect_to listings_path
    else
      render "new"
    end
  end

  def update
  end

  def list
    @shifts = Shift.all
  end

  def departments
    store_id = params[:store]
    if store_id != nil
      render :json => all_departments
    else
      render :json => departments_by_store(store_id)
    end
  end
end
