class User < ApplicationRecord
    belongs_to :store, optional: true
    
    has_secure_password

    validates :name, presence: { message: 'is required' }
    validates :email, presence: { message: 'is required' }
    validates :email, uniqueness: { message: 'is already registered' }
    validates :store, presence: { message: 'is required' }
end
