class Shift < ApplicationRecord
    belongs_to :store
    belongs_to :department
    
    belongs_to :user, optional: true

    validates :start, presence: true
    validates :end, presence: true
end
