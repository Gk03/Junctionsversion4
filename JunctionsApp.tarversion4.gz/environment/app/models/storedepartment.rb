class Storedepartment < ApplicationRecord
    belongs_to :store
    belongs_to :department
end
