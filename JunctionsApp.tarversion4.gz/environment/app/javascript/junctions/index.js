console.log('loading index from junctions');

export const getDepartments = function (store){
    console.log(store);
}