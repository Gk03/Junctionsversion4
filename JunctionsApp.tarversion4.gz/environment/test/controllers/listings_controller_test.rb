require 'test_helper'

class ListingsControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get listings_new_url
    assert_response :success
  end

  test "should get update" do
    get listings_update_url
    assert_response :success
  end

  test "should get list" do
    get listings_list_url
    assert_response :success
  end

end
