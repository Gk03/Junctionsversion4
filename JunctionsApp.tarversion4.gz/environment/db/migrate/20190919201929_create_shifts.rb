class CreateShifts < ActiveRecord::Migration[6.0]
  def change
    create_table :shifts do |t|
      t.belongs_to :store
      t.belongs_to :user
      t.belongs_to :department

      t.time :start
      t.time :end
      t.boolean :taken
      t.boolean :active

      t.timestamps
    end
  end
end
